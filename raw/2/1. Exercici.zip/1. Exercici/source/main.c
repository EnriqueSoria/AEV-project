/*---------------------------------------------------------------------------------

	Basic template code for starting a DS app

---------------------------------------------------------------------------------*/
#include <nds.h>
#include <stdio.h>
//---------------------------------------------------------------------------------
int main(void) {
	consoleDemoInit();
	int i;
	char name[11] = {0};
	for(i=0;i<PersonalData->nameLen;i++)
	  name[i] = (char)(PersonalData->name[i] & 255);
	iprintf("El nom de l'usuari es: %s\n", &name);
	iprintf("La data de naixement de l'usuari es: %i-%i\n", PersonalData->birthDay, PersonalData->birthMonth);;
	iprintf("El numero del color del tema de l'usuari es: %i\n", PersonalData->theme);
	while(1) {
		swiWaitForVBlank();
	}
}


