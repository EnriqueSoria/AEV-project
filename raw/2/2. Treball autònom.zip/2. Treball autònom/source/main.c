/*
	Salvador Llobet, Ignacio
*/

#include <nds.h>
#include <stdio.h>

int main()
{
	videoSetMode(MODE_0_2D);
	vramSetBankA(VRAM_A_MAIN_BG);

	PrintConsole topScreen;
	PrintConsole bottomScreen;
	
	consoleInit(&topScreen, 3,BgType_Text4bpp, BgSize_T_256x256, 31, 0, true, true);
	consoleInit(&bottomScreen, 3,BgType_Text4bpp, BgSize_T_256x256, 31, 0, true, true);
	
	int keys;
	
	int i;
	char name[11] = {0};
	for(i=0;i<PersonalData->nameLen;i++)
	  name[i] = (char)(PersonalData->name[i] & 255);
	  
	const char *opcions[3] = {"Nom","Data de naixement","Color del tema"};
	  
	int back = 0;
	
	while(1)
	{
		consoleDemoInit();
		
		int selected = 0;
		int selectedCategory = 0;
		
		while(!selected)
		{
			scanKeys();
			
			keys = keysDown();
			
			swiWaitForVBlank();
			consoleClear();
			
			consoleSelect(&bottomScreen);
			int di;
			for(di = 0; di < 3; di++)
				iprintf("%c%d: %s\n", di == selectedCategory ? '*' : ' ', di + 1, opcions[di]); 
			
			if(keys & KEY_UP) selectedCategory--;
			if(keys & KEY_DOWN) selectedCategory++;
			if(keys & KEY_A) selected = 1;
			if(keys & KEY_B) back = 1;
			
			if(selectedCategory < 0) selectedCategory = 2;
			if(selectedCategory >= 3) selectedCategory = 0;
			
			if(back)
			{
				consoleSelect(&topScreen);
				consoleClear();
				back = 0;
			}
		}
		
		if(selected)
		{
			consoleSelect(&topScreen);
			consoleClear();

			switch(selectedCategory)
			{
				case 0:
					iprintf("El nom de l'usuari es: %s\n", &name);
					break;
				case 1:
					iprintf("La data de naixement de l'usuari es: %i-%i\n", PersonalData->birthDay, PersonalData->birthMonth);
					break;
				case 2:
					iprintf("El numero del color del tema de l'usuari es: %i\n", PersonalData->theme);
					break;
			}
			consoleSelect(&bottomScreen);
		}
	}
}